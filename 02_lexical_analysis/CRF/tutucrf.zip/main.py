import torch
from crf_model import CRF

def main():
    # 初始化模型
    model = CRF()
    model.initialize()
    
    if 0:
        # 训练模型
        model.train("train.txt", "CRF-dataSet.model", epoch_num=5)
    else:
        # 加载模型进行预测
        parameter = torch.load("CRF-dataSet.model")
        test_sentence = "中华民族迎来了从站起来、富起来到强起来的伟大飞跃，实现中华民族伟大复兴进入了不可逆转的历史进程！"
        result = model.predict(test_sentence, parameter)
        print(result)

if __name__ == '__main__':
    main()