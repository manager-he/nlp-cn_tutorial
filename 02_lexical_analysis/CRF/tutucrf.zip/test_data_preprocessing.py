import unittest
import os
from data_preprocessing import read_template, character_tagging

class TestDataPreprocessing(unittest.TestCase):
    def setUp(self):
        """
        测试前创建临时测试文件
        """
        # 创建测试用的模板文件
        self.template_content = """# Unigram
U00:%x[-2,0]
U01:%x[-1,0]
U02:%x[0,0]

# Bigram
B"""
        self.template_file = "test_template.txt"
        with open(self.template_file, "w", encoding="utf-8") as f:
            f.write(self.template_content)

        # 创建测试用的输入文件
        self.input_content = """19980101-01-001-001/m 中共中央/nt 总书记/n
19980101-01-001-002/m 江泽民/nr"""
        self.input_file = "test_input.txt"
        with open(self.input_file, "w", encoding="gbk") as f:
            f.write(self.input_content)

        self.output_file = "test_output.txt"

    def tearDown(self):
        """
        测试后清理临时文件
        """
        for file in [self.template_file, self.input_file, self.output_file]:
            if os.path.exists(file):
                os.remove(file)

    def test_read_template(self):
        """
        测试模板文件读取功能
        """
        unigram_templates, bigram_templates = read_template(self.template_file)
        
        # 验证 Unigram 模板
        expected_unigram = [
            {"id": "U00", "positions": [-2]},
            {"id": "U01", "positions": [-1]},
            {"id": "U02", "positions": [0]}
        ]
        self.assertEqual(len(unigram_templates), len(expected_unigram))
        for template, expected in zip(unigram_templates, expected_unigram):
            self.assertEqual(template["id"], expected["id"])
            self.assertEqual(template["positions"], expected["positions"])

        # 验证 Bigram 模板
        expected_bigram = [{"id": "B", "positions": []}]
        self.assertEqual(len(bigram_templates), len(expected_bigram))
        self.assertEqual(bigram_templates[0]["id"], expected_bigram[0]["id"])

    def test_character_tagging(self):
        """
        测试字符标注功能
        """
        character_tagging(self.input_file, self.output_file)
        
        # 验证输出文件内容
        expected_output = """中\tB\n共\tM\n中\tM\n央\tE\n总\tB\n书\tM\n记\tE\n\n江\tB\n泽\tM\n民\tE\n\n"""
        with open(self.output_file, "r", encoding="utf-8") as f:
            actual_output = f.read()
        
        self.assertEqual(actual_output, expected_output)

    def test_character_tagging_single_char(self):
        """
        测试单字词的标注
        """
        # 创建包含单字词的测试文件
        single_char_content = "19980101-01-001-001/m 我/r 爱/v 你/r"
        single_char_input = "test_single_char.txt"
        with open(single_char_input, "w", encoding="gbk") as f:
            f.write(single_char_content)

        output_file = "test_single_char_output.txt"
        character_tagging(single_char_input, output_file)

        # 验证输出
        expected_output = "我\tS\n爱\tS\n你\tS\n\n"
        with open(output_file, "r", encoding="utf-8") as f:
            actual_output = f.read()

        self.assertEqual(actual_output, expected_output)

        # 清理临时文件
        os.remove(single_char_input)
        os.remove(output_file)

if __name__ == '__main__':
    unittest.main()