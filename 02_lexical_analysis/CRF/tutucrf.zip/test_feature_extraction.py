import unittest
from feature_extraction import get_bigram_score

# filepath: d:\Tongji\2025aSpring\CLP\CRF\test_feature_extraction.py


class TestBigramScore(unittest.TestCase):
    def setUp(self):
        # 设置基本的bigram模板和分数映射
        self.bigram_templates = [{"id": "B", "positions": []}]
        self.score_map = {
            "BBE": 1.0,  # B->E transition
            "BSB": 0.8,  # S->B transition
            "BBB": 0.5,  # B->B transition
            "BES": 0.3   # E->S transition
        }
        self.test_sentence = "北京欢迎您"

    def test_valid_transitions(self):
        """测试有效的状态转移"""
        # B->E转移
        score = get_bigram_score(
            self.test_sentence, 1, "B", "E",
            self.bigram_templates, self.score_map
        )
        self.assertEqual(score, 1.0)

        # S->B转移
        score = get_bigram_score(
            self.test_sentence, 1, "S", "B",
            self.bigram_templates, self.score_map
        )
        self.assertEqual(score, 0.8)

    def test_unknown_transition(self):
        """测试未知的状态转移"""
        score = get_bigram_score(
            self.test_sentence, 1, "M", "M",
            self.bigram_templates, self.score_map
        )
        self.assertEqual(score, 0)

    def test_different_positions(self):
        """测试不同位置的转移分数"""
        # 位置不同但状态转移相同，分数应该相同
        score1 = get_bigram_score(
            self.test_sentence, 1, "B", "E",
            self.bigram_templates, self.score_map
        )
        score2 = get_bigram_score(
            self.test_sentence, 2, "B", "E",
            self.bigram_templates, self.score_map
        )
        self.assertEqual(score1, score2)

    def test_empty_sentence(self):
        """测试空句子"""
        score = get_bigram_score(
            "", 0, "B", "E",
            self.bigram_templates, self.score_map
        )
        self.assertEqual(score, 1.0)  # 空句子不影响状态转移分数

    def test_invalid_states(self):
        """测试无效状态标签"""
        score = get_bigram_score(
            self.test_sentence, 1, "X", "Y",  # 无效的状态标签
            self.bigram_templates, self.score_map
        )
        self.assertEqual(score, 0)

if __name__ == '__main__':
    unittest.main()