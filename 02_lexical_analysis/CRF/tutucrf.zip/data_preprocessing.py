def read_template(template_file):
    """读取特征模板文件，返回Unigram和Bigram模板列表。
    
    Args:
        template_file (str): 特征模板文件的路径。模板文件应包含Unigram和Bigram两部分。
            示例格式：
            # Unigram
            U00:%x[-2,0]
            U01:%x[-1,0]
            
            # Bigram
            B
    
    Returns:
        tuple: 返回(UnigramTemplates, BigramTemplates)
            - UnigramTemplates (list): Unigram特征模板列表，每个元素是包含id和positions的字典
                示例：[{"id": "U00", "positions": [-2]}, {"id": "U01", "positions": [-1]}]
            - BigramTemplates (list): Bigram特征模板列表
                示例：[{"id": "B", "positions": []}]
    
    Raises:
        FileNotFoundError: 如果模板文件不存在
        ValueError: 如果模板文件格式不正确
    """
    UnigramTemplates = []
    BigramTemplates = []
    switchFlag = False  # 先读Unigram，再读Bigram
    with open(template_file, encoding='utf-8') as tempFile:
        for line in tempFile:
            tmpList = []
            if line.find("Unigram") > 0 or line.find("Bigram") > 0:
                continue
            if switchFlag:  # Bigram
                # if line.find("/") > 0:
                #     left = line.split("/")[0].split("[")[-1].split(",")[0]
                #     right = line.split("/")[-1].split("[")[-1].split(",")[0]
                #     tmpList.append(int(left))
                #     tmpList.append(int(right))
                # else:
                #     num = line.split("[")[-1].split(",")[0]
                #     tmpList.append(int(num))
                BigramTemplates.append({"id":"B", "positions":[]})
            else:   # Unigram
                if len(line.strip()) == 0:
                    switchFlag = True
                else:
                    template = {"id":"", "positions":[]}
                    template["id"],feature = line.split(":")
                    positions = feature.split("/")
                    for pos in positions:
                        # 提取相对位置，例如 %x[-1,0]
                        num = pos.split("[")[-1].split(",")[0]
                        template["positions"].append(int(num))
                    UnigramTemplates.append(template)
    return UnigramTemplates, BigramTemplates


def character_tagging(input_file, output_file):
    """将原始数据集加工成4-tag形式的标注数据集。
    
    将原始分词语料转换为序列标注格式，使用BMES标注体系：
    - B: 词语的开始(Begin)
    - M: 词语的中间(Middle)
    - E: 词语的结尾(End)
    - S: 单字成词(Single)
    
    Args:
        input_file (str): 输入文件路径，要求GBK编码
            示例格式：中共中央/nt 总书记/n 江泽民/nr
        output_file (str): 输出文件路径，将以UTF-8编码保存
            输出格式：字符\t标签\n
    
    Raises:
        FileNotFoundError: 如果输入文件不存在
        IOError: 如果写入输出文件失败
        
    Examples:
        >>> character_tagging("input.txt", "output.txt")
        输入文件内容：中共中央/nt 总书记/n
        输出文件内容：
        中    B
        共    M
        中    M
        央    E
        总    B
        书    M
        记    E
    """
    with open(input_file, 'r', encoding='gbk') as input_data, open(output_file, 'w', encoding='utf-8') as output_data:
        for line in input_data.readlines():
            word_list = line.strip().split(" ")
            for word in word_list[1:]:
                words = word.split("/")
                if len(words) >= 2:
                    word = words[0]
                    if len(word) == 1:
                        output_data.write(word + "\tS\n")
                    else:
                        output_data.write(word[0] + "\tB\n")
                        for w in word[1:-1]:
                            output_data.write(w + "\tM\n")
                        output_data.write(word[-1] + "\tE\n")
            output_data.write("\n")

def get_train_data(train_file):
    """读取预处理后的训练数据集，返回字符序列和标签序列。
    
    从预处理后的文件中读取训练数据，文件中每行包含一个字符和其对应的标签，
    不同句子之间用空行分隔。返回字符序列和对应的标签序列。
    
    Args:
        train_file (str): 训练数据文件路径，要求UTF-8编码
            文件格式：字符\t标签\n，句子间用空行分隔
    
    Returns:
        tuple: 返回(X, Y)，其中：
            - X (list[str]): 字符序列列表，每个元素是一个完整句子的字符串
            - Y (list[str]): 标签序列列表，每个元素是一个完整句子的标签串
    
    Raises:
        FileNotFoundError: 如果训练文件不存在
        ValueError: 如果文件格式不正确
        
    Examples:
        >>> X, Y = get_train_data("train.txt")
        训练文件内容：
        我    B
        们    E
        
        今    B
        天    E
        
        返回结果：
        X = ["我们", "今天"]
        Y = ["BE", "BE"]
    """
    X = []
    Y = []
    with open(train_file, encoding='utf-8') as tempFile:
        x = ""
        y = ""
        for line in tempFile:
            line = line.strip()
            if line == "":
                if x and y:
                    X.append(x)
                    Y.append(y)
                x = ""
                y = ""
            else:
                data = line.split("\t")
                x += data[0]
                y += data[1]
    return X, Y