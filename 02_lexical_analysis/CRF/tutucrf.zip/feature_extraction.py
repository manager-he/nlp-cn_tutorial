def make_key(template, sentence, pos, status_covered, debug=False):
    """生成特征键值的模板标注函数。

    基于给定的模板和句子位置，生成特征函数的键值。键值格式为：
    "特征ID+上下文字符/状态标签"

    Args:
        template (dict): unigram特征模板，包含id和positions两个键
        sentence (str): 输入句子的字符串
        pos (int): 当前处理字符的位置
        status_covered (str): 状态标签，对于unigram为"B/M/E/S"之一，
                            对于bigram为两个状态的组合如"BE"
        debug (bool, optional): 是否打印调试信息。默认为False

    Returns:
        str: 特征键值字符串，格式为"ID字符串/状态"
            例如："U00北京/B"表示以"北京"为上下文，状态为"B"的特征

    Examples:
        >>> template = {"id": "U00", "positions": [-2]}
        >>> sentence = "北京欢迎您"
        >>> make_key(template, sentence, 欢, "B")
        'U00北/B'
    """
    result = template["id"]
    for i in template["positions"]:
        index = pos + i
        if index < 0 or index >= len(sentence):
            result += " "
        else:
            result += sentence[index]
    result += "/"
    result += status_covered
    if debug:
        print(result)
    return result

def get_unigram_score(sentence, this_pos, this_status, unigram_templates, score_map):
    """计算状态特征的分数总和。
    
    基于给定的unigram模板，计算当前字符在特定状态下的特征分数和。

    Args:
        sentence (str): 输入句子的字符串
        this_pos (int): 当前字符的位置
        this_status (str): 当前状态，为"B/M/E/S"之一
        unigram_templates (list[dict]): unigram特征模板列表
            每个模板包含id和positions两个键
        score_map (dict): 特征权重映射字典
            键：特征字符串，值：对应的分数

    Returns:
        float: 所有状态特征分数的总和

    Examples:
        >>> sentence = "北京欢迎您"
        >>> unigram_score = get_unigram_score(sentence, 1, "B", 
        ...     unigram_templates, score_map)
    """
    unigram_score = 0
    for i in range(len(unigram_templates)):
        key = make_key(unigram_templates[i], sentence, this_pos, this_status)
        if key in score_map:
            unigram_score += score_map[key]
    return unigram_score

def get_bigram_score(sentence, this_pos, pre_status, this_status, bigram_templates, score_map):
    """计算转移特征的分数。
    
    虽然bigram模板只有'B'，但需要考虑所有可能的状态转移特征。
    例如：B->E, M->E, S->B等所有可能的转移。

    Args:
        sentence (str): 输入句子的字符串
        this_pos (int): 当前字符的位置
        pre_status (str): 前一个状态，为"B/M/E/S"之一
        this_status (str): 当前状态，为"B/M/E/S"之一
        bigram_templates (list[dict]): bigram特征模板列表，只包含{"id": "B"}
        score_map (dict): 特征权重映射字典
            键：特征字符串（如"B BE"表示从B到E的转移）
            值：该转移特征的权重

    Returns:
        float: 转移特征的分数

    Examples:
        >>> # 假设score_map中存储了以下转移特征的权重：
        >>> score_map = {
        ...     "B BB": 0.5,  # B->B的转移
        ...     "B BE": 1.0,  # B->E的转移
        ...     "B SB": 0.8   # S->B的转移
        ... }
        >>> bigram_templates = [{"id": "B", "positions": []}]
        >>> get_bigram_score("北京", 1, "B", "E", bigram_templates, score_map)
        1.0  # 返回B->E转移的权重
    """
    # 对于只有B模板的情况，我们只关注状态转移本身
    # 特征键值格式为："B前一状态当前状态"
    key = f"B{pre_status}{this_status}"
    
    # 如果该转移特征存在于score_map中，返回其权重；否则返回0
    return score_map[key] if key in score_map else 0