import torch
from data_preprocessing import read_template, character_tagging, get_train_data
from feature_extraction import make_key, get_unigram_score, get_bigram_score
from utils import num2tag, tag2num, get_max_index, get_duplicate

class CRF:
    def __init__(self):
        self.scoreMap = {}
        self.UnigramTemplates = []
        self.BigramTemplates = []
        
    def initialize(self):
        """初始化模型配置
        
        读取特征模板文件并预处理训练数据。
        
        Raises:
            FileNotFoundError: 如果模板文件或训练数据文件不存在
        """
        self.UnigramTemplates, self.BigramTemplates = read_template("template.txt")
        character_tagging("199801.txt", "train.txt")

    def get_wrong_num(self, sentence, real_res):
        """计算预测结果中的错误标注数量
        
        Args:
            sentence (str): 输入句子
            real_res (str): 真实标签序列
            
        Returns:
            int: 预测错误的字符数量
        """
        my_res = self.viterbi(sentence)
        return sum(1 for i, j in zip(my_res, real_res) if i != j)

    def set_score_map(self, sentence, real_res, debug=False):
        """更新模型的特征权重
        
        根据预测结果和真实结果的差异，更新特征权重映射。
        对于预测错误的位置，降低错误特征的权重，提高正确特征的权重。
        
        Args:
            sentence (str): 输入句子
            real_res (str): 真实标签序列
            debug (bool, optional): 是否打印调试信息。默认为False
        """
        my_res = self.viterbi(sentence)
        for word_index in range(len(sentence)):
            my_res_i = my_res[word_index]
            theory_res_i = real_res[word_index]
            if my_res_i != theory_res_i:
                # 状态特征更新
                for uni_index, template in enumerate(self.UnigramTemplates):
                    uni_my_key = make_key(template, sentence, word_index, my_res_i)
                    if uni_my_key not in self.scoreMap:
                        self.scoreMap[uni_my_key] = -1
                    else:
                        self.scoreMap[uni_my_key] -= 1
                    
                    uni_theory_key = make_key(template, sentence, word_index, theory_res_i)
                    if uni_theory_key not in self.scoreMap:
                        self.scoreMap[uni_theory_key] = 1
                    else:
                        self.scoreMap[uni_theory_key] += 1

                # 转移特征更新
                if word_index == 0:
                    # 句子开始位置，前一状态用空格表示
                    bi_my_key = f"B {my_res_i}"
                    bi_theory_key = f"B {theory_res_i}"
                else:
                    # 非开始位置，使用前一状态和当前状态的组合
                    bi_my_key = f"B{my_res[word_index-1]}{my_res_i}"
                    bi_theory_key = f"B{real_res[word_index-1]}{theory_res_i}"
                
                # 更新错误预测的转移特征权重
                if bi_my_key not in self.scoreMap:
                    self.scoreMap[bi_my_key] = -1
                else:
                    self.scoreMap[bi_my_key] -= 1
                
                # 更新正确标注的转移特征权重
                if bi_theory_key not in self.scoreMap:
                    self.scoreMap[bi_theory_key] = 1
                else:
                    self.scoreMap[bi_theory_key] += 1

    def viterbi(self, sentence):
        """使用维特比算法进行序列标注。
        
        基于动态规划的维特比算法，找出最可能的标签序列。算法步骤：
        1. 初始化：计算每个位置、每个状态的初始得分
        2. 递推：计算每个位置上每个状态的最大得分及其来源状态
        3. 回溯：从后向前构造最优路径
        
        Args:
            sentence (str): 待标注的句子
                
        Returns:
            str: 预测的标签序列，每个字符对应BMES中的一个标签
            
        例如：
            输入："我爱北京"
            输出："SSBE"（表示"我|爱|北京"）
        """
        lens = len(sentence)
        status_from = [[""] * lens for _ in range(4)]  # B,M,E,S
        max_score = [[0] * lens for _ in range(4)]
        
        for word_index in range(lens):
            for state_num in range(4):
                this_status = num2tag(state_num)
                if word_index == 0:
                    uni_score = get_unigram_score(sentence, 0, this_status, 
                                                self.UnigramTemplates, self.scoreMap)
                    bi_score = get_bigram_score(sentence, 0, " ", this_status,
                                              self.BigramTemplates, self.scoreMap)
                    max_score[state_num][0] = uni_score + bi_score
                    status_from[state_num][0] = None
                else:
                    scores = [0] * 4
                    for i in range(4):
                        pre_status = num2tag(i)
                        trans_score = max_score[i][word_index - 1]
                        uni_score = get_unigram_score(sentence, word_index, this_status,
                                                    self.UnigramTemplates, self.scoreMap)
                        bi_score = get_bigram_score(sentence, word_index, pre_status, this_status,
                                                  self.BigramTemplates, self.scoreMap)
                        scores[i] = trans_score + uni_score + bi_score
                    max_index = get_max_index(scores)
                    max_score[state_num][word_index] = scores[max_index]
                    status_from[state_num][word_index] = num2tag(max_index)

        res_buf = [""] * lens
        if lens > 0:
            score_buf = [max_score[i][lens - 1] for i in range(4)]
            res_buf[lens - 1] = num2tag(get_max_index(score_buf))
            
        for back_index in range(lens - 2, -1, -1):
            res_buf[back_index] = status_from[tag2num(res_buf[back_index + 1])][back_index + 1]
            
        return "".join(res_buf)

    def train(self, data_file, model_path, epoch_num=3):
        """训练CRF模型
        
        使用预处理后的训练数据训练模型，使用前80%的数据作为训练集，
        后20%的数据作为测试集。每轮训练后都保存模型。
        
        Args:
            data_file (str): 训练数据文件路径
            model_path (str): 模型保存路径
            epoch_num (int, optional): 训练轮数。默认为3
            
        Example:
            >>> crf.train("train.txt", "model.pkl", epoch_num=5)
            epoch1: 准确率 0.8956
            测试集准确率: 0.8732
        """
        sentences, results = get_train_data(data_file)
        whole = len(sentences)
        train_num = int(whole * 0.8)
        
        for epoch in range(1, epoch_num):
            wrong_num = total_test = 0
            for i in range(train_num):
                sentence = sentences[i]
                total_test += len(sentence)
                result = results[i]
                self.set_score_map(sentence, result)
                wrong_num += self.get_wrong_num(sentence, result)
                if i % 100 == 0 and i != 0:
                    print(f"epoch{epoch}: 训练进度 {i}/{train_num}，准确率 {1 - wrong_num / total_test:.4f}")
                
            correct_num = total_test - wrong_num
            print(f"epoch{epoch}: 准确率 {correct_num/total_test:.4f}")
            
            total = correct = 0
            for i in range(train_num, whole):
                sentence = sentences[i]
                total += len(sentence)
                result = results[i]
                my_res = self.viterbi(sentence)
                correct += get_duplicate(result, my_res)
                
            accuracy = correct / total
            print(f"测试集准确率: {accuracy:.4f}")
            
            self.save_model(model_path)

    def save_model(self, model_path):
        """保存模型参数
        
        将模型的特征权重和模板保存到文件。
        
        Args:
            model_path (str): 模型保存路径
            
        Raises:
            IOError: 如果保存模型时出错
        """
        torch.save({
            'scoreMap': self.scoreMap,
            'BigramTemplates': self.BigramTemplates,
            'UnigramTemplates': self.UnigramTemplates
        }, model_path)

    def predict(self, sentence, parameter):
        """对输入句子进行分词
        
        使用训练好的模型对输入句子进行分词。
        
        Args:
            sentence (str): 待分词的句子
            parameter (dict): 模型参数，包含scoreMap和特征模板
            
        Returns:
            list[str]: 包含一个元素的列表，元素为分词结果，
                      词语之间用'|'分隔
                      
        Example:
            >>> parameter = torch.load("model.pkl")
            >>> result = crf.predict("我爱北京天安门", parameter)
            >>> print(result[0])
            '我|爱|北京|天安门'
        """
        self.scoreMap = parameter['scoreMap']
        self.UnigramTemplates = parameter['UnigramTemplates']
        self.BigramTemplates = parameter['BigramTemplates']
        
        tags = self.viterbi(sentence)
        
        # 修正最后一个字的状态
        if tags[-1] in ['B', 'M']:
            if tags[-2] in ['B', 'M']:
                tags = tags[:-1] + 'E'
            else:
                tags = tags[:-1] + 'S'
        
        # 生成分词结果
        result = ''
        for i, (char, tag) in enumerate(zip(sentence, tags)):
            result += char
            if tag in ['S', 'E'] and i < len(sentence) - 1:
                result += '|'
                
        return [result]