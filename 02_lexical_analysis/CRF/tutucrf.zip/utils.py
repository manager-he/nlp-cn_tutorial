def num2tag(number):
    """将数字转为对应标志"""
    tags = {0: "B", 1: "M", 2: "E", 3: "S"}
    return tags.get(number)

def tag2num(status):
    """将标志转为对应数字"""
    tags = {"B": 0, "M": 1, "E": 2, "S": 3}
    return tags.get(status, -1)

def get_max_index(lst):
    """获得最大值对应的索引"""
    return lst.index(max(lst))

def get_duplicate(s1, s2):
    """计算两个状态序列中相同的状态数"""
    return sum(1 for x, y in zip(s1, s2) if x == y)